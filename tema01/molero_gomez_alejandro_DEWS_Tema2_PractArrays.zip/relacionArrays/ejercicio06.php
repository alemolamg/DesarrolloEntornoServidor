<?php
    $ciudades = array("Madrid", "Barcelona", "Londres", "New York","Los Ángeles", "Chicago");
    
    foreach ($ciudades as $indice => $nombre) {
        echo "La ciudad con índice $indice tiene el nombre de $nombre <br/>";
    }

?>
