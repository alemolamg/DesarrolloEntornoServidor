<?php

class JaulaHistorial {
     
}
