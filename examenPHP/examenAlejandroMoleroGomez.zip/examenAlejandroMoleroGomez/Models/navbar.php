<!-- Muestra una especie de barra de navegación -->
<div id="principal" class="bg-success py-1">
    <h1 class="text-center p-2 text-white ">Zoo</h1>
    <div id="navbar" class="row">
        <!-- <div class="d-flex justify-content-center"> -->
        <div class="col bg-light py-1"><a href="../Views/nuevoAnimal.php">Nuevo Animal</a></div>
        <div class="col bg-light py-1"><a href="../Views/moverAnimal.php">Mover Animal</a></div>
        <div class="col bg-light py-1"><a href="../Controllers/cerrarSesion.php">Cerrar Sesión</a></div>
    </div>
</div>