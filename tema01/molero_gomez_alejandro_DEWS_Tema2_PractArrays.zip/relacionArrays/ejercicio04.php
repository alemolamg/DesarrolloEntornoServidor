<?php
    $persona = array("nombre" => "Pedro Torres", "direccion" => "C/ Mayor, 37", "telefono" => "123456789");
    
    foreach ($persona as $key => $valor) {
        echo "<br/> $key: $valor";
    }

?>

